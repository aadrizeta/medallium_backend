# medallium_backend

Medallium es una herramienta esencial para todos los fans de Yo-Kai Watch, ofreciendo un catálogo completo de Yo-Kai con descripciones, habilidades y 
evoluciones, funciones de búsqueda avanzadas, guía de localización y consejos para capturar y utilizar Yo-Kai.

# Diseño en Figma: https://www.figma.com/design/sye14AtClDHvzn6gu2e2GF/MEDALLIUM---DAM2?node-id=0-1&p=f&t=2NcWjIh0hryq6wOh-0

Nombre: Medallium Presentación del Proyecto: Yo-Kai Watch Yo-Kai Watch es una popular franquicia que ha capturado la imaginación de jugadores de todo el 
mundo con sus coloridos y carismáticos Yo-Kai. Cada Yo-Kai tiene su propia personalidad, habilidades únicas e historias fascinantes. Sin embargo, con la gran cantidad de Yo-Kai 
disponibles, puede ser difícil para los jugadores llevar un seguimiento de todos ellos y descubrir sus secretos. Nuestro proyecto se enfoca en crear una aplicación de Yo-Kai Watch 
que permitirá a los jugadores obtener información detallada y organizada sobre todos los Yo-Kai disponibles. Esta aplicación ofrecerá a los jugadores las siguientes funcionalidades:
# Listado completo de Yo-Kai: Un catálogo exhaustivo de todos los Yo-Kai, con descripciones detalladas, habilidades y evoluciones.
# Búsqueda y filtro: Herramientas avanzadas de búsqueda y filtrado para que los jugadores puedan encontrar rápidamente los Yo-Kai que necesitan.
# Guía de localización: Información sobre dónde y cómo encontrar a cada Yo-Kai en el juego.
# Registro personalizado: Funcionalidad para que los jugadores puedan marcar los Yo-Kai que ya han encontrado y aquellos que aún están buscando.
