package com.app.medallium;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MedalliumApplication {

	public static void main(String[] args) {
		SpringApplication.run(MedalliumApplication.class, args);
	}

}
