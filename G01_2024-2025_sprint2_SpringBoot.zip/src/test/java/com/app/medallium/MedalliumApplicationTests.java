package com.app.medallium;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MedalliumApplicationTests {

	@Test
	void contextLoads() {
	}

}
